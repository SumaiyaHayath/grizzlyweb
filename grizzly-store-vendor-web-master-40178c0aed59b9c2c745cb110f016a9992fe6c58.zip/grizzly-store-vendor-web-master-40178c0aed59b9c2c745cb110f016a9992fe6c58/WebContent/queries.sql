CREATE TABLE `vendor_data` (
  `vendor_name` varchar(45) NOT NULL,
  `vendor_pwd` varchar(45) DEFAULT NULL,
  `mobile_no` int(11) DEFAULT NULL,
  `address` varchar(45) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  `vendor_rating` float DEFAULT NULL,
  PRIMARY KEY (`vendor_name`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `product_table` (
  `product_list` varchar(45) DEFAULT NULL,
  `brand` varchar(45) DEFAULT NULL,
  `category` varchar(45) DEFAULT NULL,
  `rating` float DEFAULT NULL,
  `product_id` int(11) NOT NULL,
  `description` varchar(45) DEFAULT NULL,
  `price` int(11) DEFAULT NULL,
  `offer` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

CREATE TABLE `inventory` (
  `product_id` int(11) NOT NULL,
  `in_stock` int(11) DEFAULT NULL,
  `buffer` int(11) DEFAULT NULL,
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;