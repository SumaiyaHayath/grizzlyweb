package com.cognizant.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.Statement;

import com.cognizant.bean.productBean;

public class productDao {
	public static Connection Connect() throws Exception {

		Connection conn = null;
		Class.forName("com.mysql.jdbc.Driver");
		conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/test", "root", "root");
		return conn;
	}

	public int insert(productBean pb) throws Exception

	{
		Connection conn = Connect();
		String insertQuery = "insert into product_table (product_id,category,product_list,description,price)values(?,?,?,?,?)";
		String Query = "insert into inventory (product_id)values(?)";
		PreparedStatement ps = conn.prepareStatement(insertQuery);
		PreparedStatement ps1 = conn.prepareStatement(Query);
		ps.setInt(1, pb.getProductId());
		ps.setString(2, pb.getCategory());
		ps.setString(3, pb.getProductList());
		ps.setString(4, pb.getDescription());
		ps.setInt(5, pb.getPrice());
		ps1.setInt(1, pb.getProductId());
		int insertStatus = 0;
		insertStatus = ps.executeUpdate();
		return insertStatus;
	}

	public int delete(String productList) throws Exception {
		Connection conn = Connect();
		String delQuery = "delete from product_table where product_list='" + productList + "'";
		int delStatus = 0;
		Statement st = conn.createStatement();
		delStatus = st.executeUpdate(delQuery);
		return delStatus;
	}

}